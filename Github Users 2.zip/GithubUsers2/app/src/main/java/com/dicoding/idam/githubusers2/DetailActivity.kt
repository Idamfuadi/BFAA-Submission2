package com.dicoding.idam.githubusers2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.dicoding.idam.githubusers2.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    companion object {
        const val EXTRA_DATA = "extra_data"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userData = intent.getParcelableExtra<GithubUser>(EXTRA_DATA) as GithubUser
        Glide.with(this)
            .load(userData.avatar)
            .into(binding.userAvatar)
        binding.username.text = userData.login
        binding.tvNameOfUser.text = userData.username
    }
}