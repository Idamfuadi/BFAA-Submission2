package com.dicoding.idam.githubusers2

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import org.json.JSONObject

class MainViewModel : ViewModel() {

    val listUsers = MutableLiveData<ArrayList<GithubUser>>()

    fun setUserNames(username: String) {
        val url = "https://api.github.com/search/users?q=$username"

        val client = AsyncHttpClient()
        client.addHeader("Authorization", "token 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")
        client.addHeader("User-Agent", "request")
        client.get(url, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray
            ) {
                try {
                    val result = String(responseBody)
                    val responseObject = JSONObject(result)
                    val userCount = responseObject.getJSONArray("items")
                    Log.d("TAG", result)
                    for (i in 0 until userCount.length()) {
                        val user = userCount.getJSONObject(i)
                        val loginUser: String = user.getString("url")
                        getDetailUser(loginUser)
                    }
                } catch (e: Exception) {
                    Log.d("Exception", e.message.toString())
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>,
                responseBody: ByteArray,
                error: Throwable?
            ) {
                Log.d("Failure", error?.message.toString())
            }

        })
    }

    private fun getDetailUser(username: String) {
        val userData = ArrayList<GithubUser>()

        val client = AsyncHttpClient()
        client.addHeader("Authorization", "token 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")
        client.addHeader("User-Agent", "request")
        client.get(username, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray
            ) {
                try {
                    val result = String(responseBody)
                    val responseObject = JSONObject(result)
                    val githubUser = GithubUser()
                    githubUser.avatar = responseObject.getString("avatar_url").toString()
                    githubUser.login = responseObject.getString("login").toString()
                    githubUser.username = responseObject.getString("name").toString()
                    githubUser.company = responseObject.getString("company").toString()
                    githubUser.following = responseObject.getString("following").toString()
                    githubUser.followers = responseObject.getString("followers").toString()
                    userData.add(githubUser)

                    listUsers.postValue(userData)
                } catch (e: Exception) {
                    Log.d("Exception", e.message.toString())
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                Log.d("FailureUserDetail", error?.message.toString())
            }
        })
    }

//    fun setUser(users: String) {
//        // request API
//    }

    fun getUsers(): LiveData<ArrayList<GithubUser>> {
        return listUsers
    }
}